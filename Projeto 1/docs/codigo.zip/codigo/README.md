[![ Abrir no código do Visual Studio ](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo=_id=82079 Atribuição Repo)
#Nome  do projeto

Escreva um ou dois parágrafos resumindo o objetivo do seu projeto.

##  Alunos trabalhadores da equipe

* João Victor Temponi Daltro de Castro
* Maurício Fernandes Leite
* Miguel Martins Fonseca da Cruz
* Rúbia Coelho de Matos


##  Professores responsáveis

* João Caram Santos de Oliveira
