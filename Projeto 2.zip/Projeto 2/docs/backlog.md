| Usuário      | Requisito | Motivação     |
| :----:        |    :----:   |          :----: |
| Como um XXXXXX, eu quero      | --requsito--       | para...    |
| Como um XXXXXX, eu quero   | --requisito--         | para...      |



> Written with [StackEdit](https://stackedit.io/).
