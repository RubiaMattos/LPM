# Documentação do Projeto

A documentação do projeto é composta pelos seguintes itens: 
 - [Diagramas de classe do projeto (histórico de versões)](/docs/diagramas/)
 - [Plano de testes (quando aplicável)](/docs/planoDeTestes.md)
 - [Backlog do projeto (requisitos implementados)](/docs/backlog.md)
 - [Instruções para uso](/docs/instrucoes.md)
 - [Link para o vídeo de apresentação (edite este mesmo md para colocar sua URL)](http://insira.aqui.sua.URL)

