public class GrafoNãoPonderado extends GrafoMutavel {

    public GrafoNãoPonderado(String nome) {
        super(nome);
    }

    public boolean addAresta(int origem, int destino) {
        return false;
    }

    public Grafo subGrafo(Lista<Vertice> vertices) {
        Grafo subgrafo = new Grafo("Subgrafo de " + this.nome);

        return subgrafo;
    }
    
}
