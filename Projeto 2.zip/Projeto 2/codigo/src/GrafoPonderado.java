public class GrafoPonderado extends GrafoMutavel {

    public GrafoPonderado(String nome) {
        super(nome);
    }

    public boolean addAresta(int origem, int destino) {
        return false;
    }

    public boolean addAresta(int origem, int destino, int peso) {
        return this.arestas.add(destino, new Aresta(0, destino));
    }

    public void carregar(String nomeArquivo) {

    }
    
    public Grafo subGrafo(Lista<Vertice> vertices) {
        Grafo subgrafo = new Grafo("Subgrafo de " + this.nome);

        return subgrafo;
    }
}
