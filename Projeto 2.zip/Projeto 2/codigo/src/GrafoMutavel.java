public abstract class GrafoMutavel extends Grafo {

    public GrafoMutavel(String nome) {
        super(nome);
    }
    
    public boolean addAresta(int origem, int destino) {
        return false;
    }

    public boolean addVertice(Vertice novo) {
        return false;
    }

    public void carregar(String nomeArquivo) {
        
    }

    public boolean delAresta(int origem, int destino) {
        return false;
    }

    public boolean delVertice(int idVertice) {
        return false;
    }
    
    public void salvar(String nomeArquivo) {
    }
}
