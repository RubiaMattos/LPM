public class GrafosCompleto extends Grafo {

    public int ordem;

    public GrafosCompleto(String nome) {
        super(nome);
    }

    public boolean completo() {
    }
    
    public Aresta existeAresta(int verticeA, verticeB){

    }

    public Vertice existeVertice(int idVertice){

    }

    public boolean euleriano() {

    }
    
    public GrafosCompleto subGrafo(Lista<Vertice> vertices) {
        GrafosCompleto subgrafo = new Grafo("Subgrafo de " + this.nome);

        return subgrafo;
    }

}
